using System;
using UnityEngine;

namespace Unity.Multiplayer.Samples.Utilities
{
    public class DontDestroyOnLoad : MonoBehaviour
    {
        void Awake()
        {
            DontDestroyOnLoad(gameObject);
        }
    }
}
